# Verification Log — NovaTech Revenue Intelligence Dashboard

Use actual Quick Chat responses and compare them to the Data Dictionary. Complete at least 6 entries covering CRM Deals, Marketing Campaigns, and Support Tickets.

For each entry record:
- **Knowledge base/domain:**
- **Question asked in Quick Chat:**
- **Quick Chat response (quote or concise capture):**
- **Expected answer from Data Dictionary / verified dataset:**
- **Pass/Fail:**
- **Evidence screenshot filename:**
- **Notes / discrepancy and follow-up:**

## Entry 1 — CRM Deals
- Question:
- Quick Chat response:
- Expected answer:
- Pass/Fail:
- Screenshot:
- Notes:

## Entry 2 — CRM Deals
- Question:
- Quick Chat response:
- Expected answer:
- Pass/Fail:
- Screenshot:
- Notes:

## Entry 3 — Marketing Campaigns
- Question:
- Quick Chat response:
- Expected answer:
- Pass/Fail:
- Screenshot:
- Notes:

## Entry 4 — Marketing Campaigns
- Question:
- Quick Chat response:
- Expected answer:
- Pass/Fail:
- Screenshot:
- Notes:

## Entry 5 — Support Tickets
- Question:
- Quick Chat response:
- Expected answer:
- Pass/Fail:
- Screenshot:
- Notes:

## Entry 6 — Support Tickets
- Question:
- Quick Chat response:
- Expected answer:
- Pass/Fail:
- Screenshot:
- Notes:
