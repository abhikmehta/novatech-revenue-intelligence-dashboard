NOVATECH REVENUE INTELLIGENCE DASHBOARD — SUBMISSION WORKSPACE
Suggested Desktop folder name: NovaTech_Revenue_Intelligence_Submission_AM

This folder is organized to match the Udacity project deliverables and rubric. It is a local working folder: the actual datasets, analysis, Topic, dashboard, and Space/QuickSuite work must be created in the Vocareum/Amazon Quick environment.

IMPORTANT
- This folder is a submission scaffold, not proof that project tasks have been completed.
- Use actual results from the provided NovaTech files and QuickSuite. Do not invent row counts, Q responses, KPI values, findings, or screenshots.
- Keep all three source CSVs and all four datasets (three sources + unified dataset) saved to SPICE in Quick.
- Your final submission ZIP must include the required artifacts. The course specifically asks for a dashboard PDF with all three sheets, logs, screenshots, executive summary text if available, and the written report.

FOLDER GUIDE
00_Project_Admin
  Artifact_Status_Tracker.csv and this guide. Keep project status and final review notes here.
01_Reference_Documents
  Copy in NovaTech Company Background.pdf, Data Dictionary.pdf, Dashboard Requirements Brief.pdf, and any course templates downloaded from the classroom.
02_Source_CSVs
  Put crm_deals.csv, marketing_campaigns.csv, and support_tickets.csv here.
03_Verification_Log
  Complete Verification_Log_Template.md with at least 6 entries across all three pre-indexed knowledge bases. Each entry must include question, Q response, expected answer from the data dictionary, and pass/fail.
04_Data_Transformation_Evidence
  Save screenshots of import/SPICE counts and columns, data type corrections, calculated fields, join diagram, join configuration, and unified dataset. Ensure screenshots show the anchor table and join type where possible.
05_Dashboard_PDF_and_Executive_Summary
  Save the exported dashboard PDF covering Marketing Funnel, Sales Pipeline, and Customer Health. Save auto-generated dashboard executive summary text here if available.
06_QuickChat_Baseline_Before_Topic
  Save screenshots of 2–3 baseline Quick Chat questions and responses before configuring the Topic. Reuse the same questions after Topic setup.
07_Topic_Setup_and_After_Topic
  Save Topic configuration screenshots and screenshots of the same 2–3 questions answered after Topic setup.
08_Q_Exploration_Log
  Complete Q_Exploration_Log_Template.md with at least 5 entries across all three domains, including one cross-dataset question. Each entry includes question, Q response, and dashboard verification.
09_Annotated_Dashboard_Screenshots
  Save screenshots of all three sheets and 3–5 visible annotations. Each annotation should state a quantified finding, business implication, and recommended action.
10_Written_Report
  Complete Written_Report_Template.docx as a 1–3 page report for VP Sarah Chen. Cover data strategy, dashboard design rationale, Topic effects on Q accuracy, key insights and actions, and where AI analysis agreed/disagreed with the dashboard. Define technical terms on first use; no raw SQL/formulas.
11_Final_Review
  Store a copy of the final checklist and any notes; final ZIP should contain the artifacts required by the course.

SCREENSHOT NAMING SUGGESTION
01_crm_import_spice_counts.png
02_marketing_import_spice_counts.png
03_support_import_spice_counts.png
04_data_type_corrections.png
05_calculated_fields.png
06_unified_join_diagram.png
07_join_configuration.png
08_marketing_funnel_sheet.png
09_sales_pipeline_sheet.png
10_customer_health_sheet.png
11_baseline_q_question1.png
12_baseline_q_question2.png
13_topic_configuration.png
14_after_topic_question1.png
15_after_topic_question2.png
16_cross_sheet_navigation.png
17_filters_and_one_click_interaction.png
18_dashboard_annotations.png

FINAL CHECKLIST
[ ] Read all three reference documents.
[ ] Verification log has 6+ entries across CRM Deals, Marketing Campaigns, and Support Tickets, with question, Q response, expected answer, pass/fail.
[ ] All 3 source CSVs and unified dataset saved to SPICE; counts and columns verified.
[ ] Data type correction screenshots captured.
[ ] At least 2 business-logic calculated fields created and screenshotted.
[ ] Join diagram/configuration screenshots show anchor table and join type.
[ ] Dashboard has Marketing Funnel, Sales Pipeline, Customer Health sheets.
[ ] Each sheet has at least one KPI and multiple appropriate visuals.
[ ] At least 2 sheets have filter controls.
[ ] One-click filtering works on at least 2 visuals.
[ ] Cross-sheet navigation works.
[ ] Dashboard published and PDF export covers all 3 sheets.
[ ] Baseline screenshots show 2–3 Q questions before Topic configuration.
[ ] Topic setup screenshot saved; same questions repeated after Topic configuration.
[ ] Q Exploration Log has 5+ entries across all domains, including a cross-dataset question, with dashboard verification.
[ ] Dashboard has 3–5 annotations, each with quantified finding, business implication, and recommended action.
[ ] Executive summary text saved if available in workspace.
[ ] Written report is 1–3 pages and covers all required topics.
[ ] Final ZIP is under 500 MB and contains required artifacts.
